import requests
import json
import boto3

class API:
    def __init__(self, api_name, url):
        self.connect_dynamodb()
        self.get_api_key(api_name)

        self.url = url

    
    def get_api_key(self, name):
        with open('creds.json', 'r') as f:
            self.key = json.load(f)[name]


    def connect_dynamodb(self):
        with open("creds.json", "r") as f:
            creds = json.load(f)
            iam_user = "crawly"
            session = boto3.Session(
                region_name='us-east-2',
                aws_access_key_id=creds[iam_user]["access"],
                aws_secret_access_key=creds[iam_user]["secret"],
            )
            ddb = session.resource('dynamodb')
            self.properties = ddb.Table('properties')
            self.companies = ddb.Table('companies')


    def get_query(self, params, select=[]):
        result = requests.get(self.url.format(**params)).json()
        if select:
            result = {key: value for (key, value) in result.items() if key in select}
        
        return result


    def get_uniques(self, key, table="properties"):
        table = getattr(self, table)
        scan = table.scan()
        items = scan['Items']

        uniques = []
        for item in scan['Items']:
            if item[key] not in uniques:
                uniques.append(item[key])

        return uniques

if __name__ == "__main__":
    url = "https://finnhub.io/api/v1/stock/profile2?symbol={symbol}&token={apikey}"
    api = API('finnhub', url)

    inc_names = api.get_uniques("company_name")
    count = 0
    for inc in inc_names:
        ticker = input(f"\nSymbol for {inc}: ")
        overview = api.get_query(params={"symbol": ticker, "apikey": api.key})
        
        item = {
            "company_name": inc,
            "attributes": {
                f"{api.key}_key": ticker
            }
        }
        for key, val in overview.items():
            item["attributes"][key] = str(val)

        resp = api.companies.put_item(Item=item)
        print(item)
        count += 1 if resp['ResponseMetadata']['HTTPStatusCode'] == 200 else 0
    print(f"\nUpdated {count} items in table companies")
    


