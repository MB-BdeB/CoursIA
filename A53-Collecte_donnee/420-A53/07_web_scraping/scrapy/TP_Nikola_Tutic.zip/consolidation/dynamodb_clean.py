import sys
import os
import json
import boto3
import mysql.connector


class DynamoDB:
    def __init__(self, table):
        self.connect_aws()


    def connect_aws(self):
        with open("creds.json", "r") as f:
            creds = json.load(f)
            iam_user = "crawly"
            session = boto3.Session(
                region_name='us-east-2',
                aws_access_key_id=creds[iam_user]["access"],
                aws_secret_access_key=creds[iam_user]["secret"],
            )

        ddb = session.resource('dynamodb')
        self.properties = ddb.Table('properties')
        self.companies = ddb.Table('companies')


    def out_fields(self, item):
        fields = {
            "name": "property name",
            "city": "city",
            "sector": ["sector", "property type"]
        }

        item['fields'] = {}
        for attribute, value in item['attributes'].items():
            for field, keys in fields.items():
                if attribute.lower() in keys:
                    item['fields'][field] = value
                    break

        return item


if __name__ == "__main__":
    db = "database-aec-acquisition"
    ddb = DynamoDB(db)
    properties = ddb.properties.scan()["Items"]
    count = 0
    for property in properties:
        resp = ddb.properties.put_item(
            Item=ddb.out_fields(property)
        )
        count += 1 if resp['ResponseMetadata']['HTTPStatusCode'] == 200 else 0
    print(f"Updated {count} items in table properties")