import sys
import os
import json
import boto3
import mysql.connector

class DDB_to_RDS:
    def __init__(self, table):
        self.connect_aws()
        self.connect_rds(table)

        self.url = url


    def connect_aws(self):
        with open("creds.json", "r") as f:
            creds = json.load(f)
            iam_user = "crawly"
            session = boto3.Session(
                region_name='us-east-2',
                aws_access_key_id=creds[iam_user]["access"],
                aws_secret_access_key=creds[iam_user]["secret"],
            )

            self.rds = boto3.client(
                'rds',
                region_name = 'us-east-1',
                aws_access_key_id = creds[iam_user]["access"],
                aws_secret_access_key = creds[iam_user]["secret"]
            )
    

        ddb = session.resource('dynamodb')
        self.properties = ddb.Table('properties')
        self.companies = ddb.Table('companies')

        
    def connect_rds(self, db):
        ENDPOINT="database-aec-acquisition.ckevwfds2zbu.us-east-1.rds.amazonaws.com"
        PORT="3306"
        USER="crawly"
        REGION="us-east-1"
        DBNAME=db
        os.environ['LIBMYSQL_ENABLE_CLEARTEXT_PLUGIN'] = '1'

        token = self.rds.generate_db_auth_token(DBHostname=ENDPOINT, Port=PORT, DBUsername=USER, Region=REGION)

        conn =  mysql.connector.connect(host=ENDPOINT, user=USER, passwd=token, port=PORT, database=DBNAME, ssl_ca='SSLCERTIFICATE')
        self.cur = conn.cursor()    


    def transfer(self, table, items, overwrite=True):
        if overwrite:
            try:
                self.cur.execute("""DROP TABLE properties""")
                query_results = cur.fetchall()
                print(query_results)
            except Exception as e:
                print("Database connection failed due to {}".format(e))          


    def clean_fields(self, item):
        fields = {

        }

        return item


if __name__ == "__main__":
    db = "database-aec-acquisition"
    d2r = DDB_to_RDS(db)
    properties = d2r.properties.scan()["Items"]
    d2r.transfer(properties)
    pass
    