import scrapy
import pandas as pd


class OpiSpider(scrapy.Spider):
    name = 'opi'
    allowed_domains = ['opireit.com']
    start_urls = ['https://www.opireit.com/properties/default.aspx']

    def parse(self, response):
        xslx_url = "http:" + response.css('div.property-map a[target="_blank"]::attr(href)').get()
        data = pd.read_excel(xslx_url,'Property List')
        data = data.rename(columns=data.iloc[0]).drop(0)
        for i, row in data.iterrows():
            item = {}
            row = dict(row)
            item["property_address"] = row.pop("Property Address")
            item["company_name"] = "OPI REIT"
            item["attributes"] = {}
            for key, val in row.items():
                item["attributes"][key] = val
            yield item


            