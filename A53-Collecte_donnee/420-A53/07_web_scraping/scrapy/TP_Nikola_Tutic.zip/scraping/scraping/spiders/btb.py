import scrapy
from contextlib import suppress

class BtbSpider(scrapy.Spider):
    name = 'btb'
    allowed_domains = ['btbreit.com']
    start_urls = ['https://www.btbreit.com/real-estate-portfolio/']

    def parse(self, response):
        listings = response.css('div.wpsight-listings div.listing')      
        for listing in listings:
            item = {'attributes': {}}
            item['company_name'] = 'BTB Real Estate Investment Trust'
            item['property_address'] = listing.css('h3.entry-title a::text')[0].get()
            item['attributes']['url'] = listing.css('h3.entry-title a::attr(href)')[0].get()
            
            request = scrapy.Request(
                item['attributes']['url'], 
                callback=self.parse_property,
                cb_kwargs=dict(main_url=response.url)
            )
            request.cb_kwargs['item'] = item

            yield request
        

        if next := response.css("a.next::attr(href)"):
            yield scrapy.Request(next[0].get(), self.parse)


    def parse_property(self, response, main_url, item):
        for category in response.css('div.single_listing_title_details h5'):
            val, vals = '', category.css('h5::text')
            for selector in vals:
                val += " " + selector.get()
            if category.css('i.fa-map-marker'):
                item['attributes']['city'] = val
            elif category.css('i.fa-industry') or category.css('i.fa-shopping-bag') or category.css('i.fa-building'):
                item['attributes']['sector'] = val

        selectors = response.css('div.single_listing_description_main_content::text') + \
                    response.css('div.single_listing_description_main_content p::text')
        vals = [sel.get() for sel in selectors]
        description = '\n'.join(vals)
                    
        with suppress(IndexError): item['attributes']['description'] = description

        # Attributs modaux
        modals = response.css('div.single_listing_building_details div.single_detail') + \
                 response.css('div.leasing_details div.single_detail') + \
                 response.css('div.single_accessibility')
        for modal in modals:
            key, val = '', ''
            with suppress(IndexError): key = modal.css('h6::text')[0].get()
            with suppress(IndexError): val = modal.css('p::text')[0].get()
            if key and val:
                item['attributes'][key] = val

        # Latitude, longitude
        if script_sel := response.css('div.googleMaps script')[0]:
            latlng = script_sel.re("(?<=new google.maps.LatLng\().*(?=\);)")[0]
            item['attributes']['lat'] = latlng.split(',')[0]
            item['attributes']['lng'] = latlng.split(',')[1]

        yield item
