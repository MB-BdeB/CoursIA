import boto3
import json
import re
import time

class AwsPipeline:
    def open_spider(self, spider):
        with open("creds.json", "r") as f:
            creds = json.load(f)
            iam_user = "crawly"
            self.session = boto3.Session(
                region_name='us-east-2',
                aws_access_key_id=creds[iam_user]["access"],
                aws_secret_access_key=creds[iam_user]["secret"],
            )
        self.ddb = self.session.resource('dynamodb')
        self.table = self.ddb.Table('properties')


    def process_item(self, item, spider):
        # Item cleaning
        item = self.clean_item(item)

        # Inserts (or squashes) item 
        insertion = self.table.put_item(Item=item)

    def clean_item(self, item):
        """
        Retrait récursif de white space
        """
        keys = list(item.keys())
        for key in keys:
            val = item.pop(key)
            key = self.clean_string(key)
            if isinstance(val, dict):
                val = self.clean_item(val)
            if isinstance(val, str):
                val = self.clean_string(val)
            item[key] = val
            
        print(json.dumps(item, indent=4))
        return item


    def clean_string(self, string):
        for duplicate in [' ', '\n', '\t']:
            string = re.sub(f'{duplicate}+', duplicate, string)
        string = re.sub('^\s+', '', string)
        string = re.sub('\s+$', '', string)
        return string